#!/bin/bash
export PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin;

## Options to be used [ -clean|-pre|-post|-eval|-help ]
usage () {
tput bold;tput smul;
echo -e "\nLinux Pre\Post Validation script - Usage :`tput sgr 0`\n"
tput bold;
echo -e "$0 [ -clean ]\t --> \tfor cleaning up output files.";
echo -e "$0 [ -pre   ]\t --> \tfor taking pre-outputs before patching.";
echo -e "$0 [ -post  ]\t --> \tfor taking post-outputs after patching.";
echo -e "$0 [ -eval  ]\t --> \tfor performing sanity check post patching.";
echo -e "$0 [ -help  ]\t --> \tfor printing the usage of the script.\n";
tput sgr 0;
}
#if [ $# != 0 ] ||  [ $1 != "-clean" ] || [ $1 != "-pre" ] || [ $1 != "-post" ] || [ $1 != "-eval" ] || [ $1 == "-help" ]
#then
#usage;exit; return 0
#fi
case $1 in
"-help" )
       usage;exit; return 0;
       ;;    
"-clean" )
       echo "Only to perform Cleanup";
       ;;
"-pre" )
       echo "Only to collect prepatch outputs";
       ;;
"-post" )
       echo "Only to collect postpatch outputsi";
       ;;
"-eval" )
       echo " To evalucate the pre & post-patch outputs & perform sanity check."
       ;;
* )
       usage;exit; return 0
       ;;
esac
