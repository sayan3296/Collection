#!/bin/bash
echo $1
echo $tag
echo $#
