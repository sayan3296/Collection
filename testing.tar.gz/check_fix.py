#!/usr/bin/python
# -*- coding: utf-8 -*-

from signal import signal, alarm, SIGALRM
from subprocess import Popen, PIPE, STDOUT
import inspect
import logging
import logging.handlers
import os
import re
import sys

VERSION='v1.4'

# Colors

PASS = '\033[92m'
FAIL = '\033[91m'
WARNING = '\033[93m'
END = '\033[0m'

#if sys.version_info[:3] < (2,4,4) :
#    sys.stdout.write('Python version found : ' +  ".".join(map(str,sys.version_info[:3])) + '\n')
#    sys.stdout.write(FAIL + 'Python Verion is too old. EXITING !!! Time to do Manual Work' + END)
#    sys.exit(2)

# Some Expected Data

rhel7 = {'channels': ['prod-rhel-x86_64-server-common-7',
         'prod-rhel-x86_64-server-optional-7', 'prod-rhn-tools-server-7'
         , 'prod-x86_64-server-7']}

rhel6 = {'channels': ['prod-rhel-x86_64-server-optional-6',
         'prod-rhn-tools-server-6', 'prod-x86_64-server-6']}

rhel5 = {'channels': ['prod-rhn-tools-server-5',
         'prod-x86_64-server-5']}

currPatch = '2Q2018'

# Initializing some variables

rhel = None
source = None
logger = None
workDir = '/tmp/OS_patching/'
logFileName = 'checks.log'
logFile = os.path.join(workDir, logFileName)

def alarm_handler(signum, frame):
    raise Alarm

    
class Alarm(Exception):
    pass


def runCmd(cmd):
    logger.debug('Running command - ' + ' '.join(cmd))
    proc = Popen(cmd, stdout=PIPE, stderr=STDOUT)
    (output, err) = proc.communicate()
    return output.strip()


def giveRC(cmd):
    proc = Popen(cmd, stdout=PIPE, stderr=STDOUT, shell=True)
    (output, err) = proc.communicate()
    return proc.returncode


def runShellCmd(cmd):
    proc = Popen(cmd, stdout=PIPE, stderr=STDOUT, shell=True)
    (output, err) = proc.communicate()
    return output.strip()


def runTimedShellCmd(cmd, time):
    cmd = 'exec ' + cmd
    signal(SIGALRM, alarm_handler)
    alarm(time * 60)
    output = None
    try:
        proc = Popen(cmd, stdout=PIPE, stderr=STDOUT, shell=True)
        (output, err) = proc.communicate()
        alarm(0)
    except Alarm:
        output = 'SCRIPT DINDT COMPLETE IN ' + str(time) \
            + '  MINUTES . I HAD TO KILL IT ! '
        proc.kill()
        proc.communicate()
    return output.strip()


def myPrint(desc):
    desc = ' ' + desc.strip() + ' '
    sys.stdout.write(desc.ljust(42, '.') + ' ')
    sys.stdout.flush()
    
def sPrint(text, end='\n'):
    sys.stdout.write(text + end)
    sys.stdout.flush()

def myStatus(status=1, warning=0):
    caller = sys._getframe(1).f_code.co_name
    if status == 0:
        sPrint(FAIL + 'Failed' + END)
        logger.error(caller + ' - Failed ! ')
    elif warning == 1:
        logger.warning(caller + ' - Finished with Warnings !')
        sPrint(WARNING + 'Warning' + END)
    elif status == 1:
        logger.info(caller + ' - Passed')
        sPrint(PASS + 'OK' + END)

    sys._getframe(1).f_code.co_name


def main():

    global rhel, source, logger, workDir

        # Make directory if doesn't exists

    if not os.path.exists(workDir):
        os.mkdir(workDir)

        # Set up Logging
    needRoll = os.path.isfile(logFile)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    #handler = logging.FileHandler(workDir + logFile)
    handler = logging.handlers.RotatingFileHandler(logFile, backupCount=5)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    if needRoll:
        logger.handlers[0].doRollover()

    logger.info('Started check.py !')

    rhel = re.findall(r'\d', runCmd(['cat', '/etc/redhat-release']))[0]
    logger.info('Found RHEL ' + rhel)

    if rhel == '7':
        source = rhel7
    elif rhel == '6':
        source = rhel6
    elif rhel == '5':
        source = rhel5
    else:
        logger.error('Cannot Determine RHEL Version')
        sys.exit(1)

    channel_yum_check()
    lvm_check()
    patch_kernel_check()
    # server_health_check()
    File_system_check()

    logger.info('Ended Checks !')


def channel_yum_check():
    global source
    myPrint(sys._getframe().f_code.co_name)
    (status, warning) = (1, 0)
    logger.info(sys._getframe().f_code.co_name + ' - started')

    channels = sorted(runCmd(['/usr/sbin/rhn-channel', '-l']).split('\n'))
    source['channels'].sort()
    expected = source['channels']
    logger.info('Expected Channels : ' + ' '.join(expected))
    logger.info('Found Channels : ' + ' '.join(channels))



    for i, channel in enumerate(channels):
        if channel.endswith('-64'):
            channels[i] = channel.replace('-64','')

        # Remove VMware channel before comparing

    for channel in channels[:]:
        if 'vmware' in channel.lower():
            logger.info('Not considering Channel : ' + channel)
            channels.remove(channel)

    lessC = set(expected) - set(channels)
    moreC = set(channels) - set(expected)
    if len(lessC) > 0:
        status = 0
        logger.error('Did not find all expected channels')
        for channel in lessC:
            logger.error('Channel : ' + channel + ' is Missing !')
    if len(moreC) > 0:
        warning = 1
        logger.warning('Found Extra Channels ! ')
        for channel in moreC:
            logger.warning('Channel : ' + channel + ' is Extra !')

    excludedPackages = []
    try:
        try:
            fd=open('/etc/yum.conf', 'rt')
            for line in fd:
                if line.startswith('exclude'):
                    for pkg in line.split(r'=')[1].split():
                        if 'sendmail' in pkg:
                            continue
                        elif 'kernel' in pkg:
                            status = 0
                            logger.error('Kernel is excluded in yum.conf !')
                        else:
                            warning = 1
                            logger.warning(pkg + ' Package is excluded in yum.conf')
        except Exception:
            fd.close()
    finally:
        fd.close()
    myStatus(status, warning)


def lvm_check():

    myPrint(sys._getframe().f_code.co_name)
    (status, warning) = (1, 0)
    logger.info(sys._getframe().f_code.co_name + ' - started')

        # PV checks

    logger.info('Checking PVs !')
    if rhel == '5':
        pvs = runCmd(['/usr/sbin/pvs', '--noheadings', '-o', 'pv_name,pv_uuid,vg_name']).splitlines()
    else:
        pvs = runCmd(['/sbin/pvs', '--noheadings', '-o', 'pv_name,pv_uuid,vg_name']).splitlines()
    for line in pvs:
        if 'unknown device' in line:
            status = 0
            (uuid, vgName) = line.split()[-2:]
            logger.error(' A PV with UUID ' + uuid + ' for VG ' + vgName + ' is Missing !')

    myStatus(status, warning)


def patch_kernel_check():

    myPrint(sys._getframe().f_code.co_name)
    (status, warning) = (1, 0)
    logger.info(sys._getframe().f_code.co_name + ' - started')

    logger.info('Checking Kernels !')

    curr_kernel = runCmd(['uname', '-r'])
    logger.info('Running Kernel : ' + curr_kernel)

    def_kernel = runCmd(['/sbin/grubby', '--default-kernel']).split('vmlinuz-')[1]
    logger.info('Default Kernel : ' + def_kernel)

    if not curr_kernel == def_kernel:
        status = 0
        logger.error('Running Kernel is not same as default kernel in Grub !')

    myStatus(status, warning)

def server_health_check():
    myPrint(sys._getframe().f_code.co_name)
    (status, warning) = (1, 0)
    logger.info(sys._getframe().f_code.co_name + ' - started')

    server_check='/usr/local/sysmgr/server_check_linux.pl'
    vendor=runCmd([r'/usr/sbin/dmidecode','-s','system-manufacturer'])
    if 'VMware' in vendor :
        if os.path.isfile(server_check):
            output=runTimedShellCmd(server_check,2)

        if (not 'No problems have been found' in output ) or ('Failed' in output):
            status = 0

    myStatus(status, warning)
    
def File_system_check():
    myPrint(sys._getframe().f_code.co_name)
    (status, warning) = (1, 0)
    logger.info(sys._getframe().f_code.co_name + ' - started')
    
    df_out_cmd=['df', '-hPT', '/', '/boot', '/var']
    my_mountPs=['/', '/boot', '/var']
    df_out=[]

    for df_line,my_mountP in zip(runCmd(df_out_cmd).splitlines()[1:],my_mountPs):
        df_out.append(df_line + ' ' + my_mountP)

    status_warning=[status,warning]
    fs_threshold_check(df_out, status_warning)
    status,warning=tuple(status_warning)

    myStatus(status, warning)

def fs_threshold_check(df_out,status_warning):
    threshold = 85
    for df_line in df_out:
        _,_,_,_,_,usePer,mountP,my_mountP=df_line.split()
        usePer=usePer.strip('%')
        logger.info('Checking ' + my_mountP + ' Partition')
        if mountP != my_mountP:
            logger.info('Seems ' + my_mountP + ' is not Separate Partition')
            continue
        logger.info(mountP + ' used is ' + usePer + '%')
        if int(usePer) > threshold:
            logger.warning(mountP + ' Partion used % is greater than ' + threshold + '%') 
            status_warning[1]=1

if __name__ == '__main__':
    main()


