#!/usr/bin/env python2.7
import os;
import sys;
from subprocess import Popen,PIPE,STDOUT;
from getopt import getopt,GetoptError;
from signal import signal,alarm,SIGALRM;
from shutil import move
import traceback;

def runCmd(cmd):
        proc=Popen(cmd,stdout=PIPE, stderr=STDOUT)
        output, err=proc.communicate()
        return output.strip()
		
def giveRC(cmd):
        proc=Popen(cmd,stdout=PIPE, stderr=STDOUT,shell=True)
        output, err=proc.communicate()
        return proc.returncode

def runShellCmd(cmd):
        proc=Popen(cmd,stdout=PIPE, stderr=STDOUT,shell=True)
        output, err =proc.communicate()
        return output.strip()
		
host=runCmd(['/bin/uname','-n'])
lt_kern='kernel' + '-' + runCmd(['uname','-r'])
rn_kern=runShellCmd(['/bin/rpm','-q','--last','kernel','|','head','-1','|','awk','{print $1}'])
rn=os.uname()
print rn
rl=rn.split(",")
print rl