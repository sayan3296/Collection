# Kernel Check
##lt_kern=`echo "kernel-$(uname -r)"`;
##rn_kern=`/bin/rpm -q --last kernel | head -1 | awk '{print $1}'`;
##
lt_kern=`/bin/rpm -q --last kernel | head -1 | awk '{print $1}'`;
rn_kern=`echo "kernel-$(uname -r)"`;
if [ $lt_kern == $rn_kern ]
then
echo "Kernel Check...............: Passed [ $(uname -r) ]"
else
echo "Kernel Check...............: Failed [ Latest Kernel is $lt_kern but Running Kernel is $rn_kern ]"
fi

#Patch & Kernel Verification
ptlvl=`cut -d':' -f1 /etc/ATTPatchlevel`
oskern=`uname -r | cut -d"." -f -6`

if [ $ptlvl == 4Q2017 ]
then
        if [ $oskern == 3.10.0-693.2.2.el7 ] || [ $oskern == 3.10.0-693.1.1.el7 ] || [ $oskern == 2.6.32-696.10.3.el6 ] || [ $oskern == 2.6.18-423.el5 ]
        then
        echo "Patch Check ...............: Passed [ $ptlvl | $oskern ]"
        else
        echo "Patch Check ...............: Failed [ Kernal mismatch with patch bundle ] "
        fi
elif [ $ptlvl == 1Q2018 ]
then
        if [ $oskern == 3.10.0-693.11.6.el7 ] || [ $oskern == 3.10.0-693.11.1.el7 ] || [ $oskern == 2.6.32-696.18.7.el6 ] || [ $oskern == 2.6.32-696.16.1.el6 ] || [ $oskern == 2.6.18-423.el5 ]
        then
        echo "Patch Check ...............: Passed [ $ptlvl | $oskern ]"
        else
        echo "Patch Check ...............: Failed [ Kernal mismatch with patch bundle ] "
        fi
elif [ $ptlvl == 2Q2018 ]
then
        if [ $oskern == 3.10.0-693.17.1.el7 ] || [ $oskern == 2.6.32-696.20.1.el6 ] || [ $oskern == 2.6.18-426.el5 ]
        then
        echo "Patch Check ...............: Passed [ $ptlvl | $oskern ]"
        else
        echo "Patch Check ...............: Failed [ Kernal mismatch with patch bundle ] "
        fi
elif [ $ptlvl == 2Q2017 ]
then
        if [ $oskern == 3.10.0-514.6.2.el7 ] || [ $oskern == 2.6.32-642.16.1.el6 ] || [ $oskern == 2.6.32-642.15.1.el6 ] || [ $oskern == 2.6.18-419.el5 ]
        then
        echo "Patch Check ...............: Passed [ $ptlvl | $oskern ]"
        else
        echo "Patch Check ...............: Failed [ Kernal mismatch with patch bundle ] "
        fi
else
echo "Patch Check ...............: Failed [ Unknown Kernel($oskern)\ Patchlevel($ptlvl)]"
fi
