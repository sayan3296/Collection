#!/usr/bin/env python2.7

from __future__ import print_function
from os import path


dirname = '/tmp/check'
files = (
    'ipaddr',
    'iplink',
    'nameip',
    'iproute',
    'fsmount'
)
errfilename = 'err'


def diff(check, f1, f2, errout=None):
    '''Diffing function'''

    lines = {}
    with open(f1) as f:
        lines[f1] = f.read().splitlines()
    with open(f2) as f:
        lines[f2] = f.read().splitlines()

    f1_extra = set(lines[f1]) - set(lines[f2])
    f2_extra = set(lines[f2]) - set(lines[f1])

    if len(f1_extra) == len(f2_extra) == 0:
        print('-->> {:>6} check........: Successful'.format(check))
        # No difference
        return

    files_to_check = {}
    if len(f1_extra) > 0:
        # File 1 has extra lines
        files_to_check[f1] = f1_extra
    if len(f2_extra) > 0:
        # File 2 has extra lines
        files_to_check[f2] = f2_extra
    print('-->> {:>6} check........: Failed [ Check {} for details ]'.format(check, errout.name))

    if errout is not None:
        errout.write('# {} check:\n\n'.format(check))
        for filename, extra in files_to_check.items():
            errout.write('### {}\n{}\n\n------------------\n'.format(
                filename,
                '\n'.join(['* Line {:3}: {}'.format(lines[filename].index(line), line) for line in extra])
            ))


def precheck():
    '''Check if all files are there'''
    for file in files:
        file1 = path.join(dirname, 'pre_{}.out'.format(file))
        file2 = path.join(dirname, 'post_{}.out'.format(file))
        if not path.isfile(file1) or not path.isfile(file2):
            print('ERROR: {} check: pre or post check file is missing')
            quit()

def run():
    '''Run CLI'''
    errfile = path.join(dirname, '{}.out'.format(errfilename))
    with open(errfile, 'w') as f:
        for check in files:
            file1 = path.join(dirname, 'pre_{}.out'.format(check))
            file2 = path.join(dirname, 'post_{}.out'.format(check))
            diff(check, file1, file2, f)



if __name__ == '__main__':
    precheck()
    run()

