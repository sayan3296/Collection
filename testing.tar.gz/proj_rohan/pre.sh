######  Working Directory
DIR=/tmp/patching/preoutputs;
if ! [ -d $DIR ] ; then /bin/mkdir -p $DIR ; fi;
cd $DIR;

##  df -hPTx tmpfs
/bin/df -hPTx tmpfs | awk 'NR > 1{print $7}' | egrep -v "^\/nas" |  sort -k 7 > df

## ip route show
/sbin/ip route show | /bin/sort > route

## network
 /sbin/ip -o addr show | /bin/awk -F 'scope' '/\<inet\>/{ split($1,a,":");gsub(/^[ \t]+/, "",a[2]);print a[2] }'| /bin/sort | /usr/bin/tr -s ' ' > ip_addr
 /sbin/ip -o link show | /bin/awk -F 'state' '/UP/{split($1,a,":");split($2,b," ");gsub(/^[ \t]+/, "",a[2]);print a[2],b[1]}' | /bin/sort > dev_state

 ## Timezone
 echo "`/bin/date | /bin/awk '{print $5}'`" > zone


