#!/usr/bin/env python

from __future__ import print_function
import os;
import sys;
import traceback;
from subprocess import Popen,PIPE,STDOUT;
import json

# Working Directory
workDir='/tmp/OS_patching/'
dumpFile=workDir+'preoutputs.json'
preOutputs={}
MOUNTs=[]
IPs=[]
NICs=[]
ROUTEs=[]
status='Failed'

def runCmd(cmd):
	proc=Popen(cmd,stdout=PIPE, stderr=STDOUT)
	output, err=proc.communicate()
	return output.strip()
	
def myPrint(desc):
	desc=' ' + desc.strip() + ' '
	print(desc.ljust(42,'.') +' ',end='')
		

def collect_IPs():
	out=runCmd(['/sbin/ip','-o','address','show'])
	for line in out.splitlines():		
		if 'inet ' in line:
			if not 'secondary' in line:
				dev=line.split()[1].strip()
			else:
				dev=line.split()[-1].strip()
			ip=line.split()[3].split(r'/')[0].strip()
			sm=line.split()[3].split(r'/')[1].strip()
			IPs.append([dev,ip,sm])	
			
def collect_NICs():
	out=runCmd(['/sbin/ip','-o','link','show'])
	for line in out.splitlines():
		if 'state UP' in line:
			dev=line.split(':')[1].strip()
			NICs.append(dev)
	
def collect_Mounts():
	out=runCmd(['df','-HPT'])
	for line in out.splitlines()[1:]:
		dev,type,size,used,avail,use,point=line.split()
		if type=='tmpfs' or r'/nas/' in point:
			continue
		dev=dev.strip()
		point=point.strip()
		type=type.strip()
		MOUNTs.append([dev,point,type])	
	
def collect_Routes():
	out=runCmd(['/sbin/route','-n'])
	for line in out.splitlines():
		if 'Kernel IP' in line or 'Destination' in line:
			continue
		dest,gw,sm=line.split()[0:3]
		dest=dest.strip()
		gw=gw.strip()
		sm=sm.strip()
		dev=line.split()[-1].strip()
		ROUTEs.append([dest,gw,sm,dev])	

def collect_Basics():
	preOutputs['kernel']=runCmd(['uname','-r'])
	preOutputs['patch']=runCmd(['cat','/etc/ATTPatchlevel']).split(r':')[0]		
	preOutputs['timeZone']=runCmd('date').split()[-2]
	preOutputs['os']=runCmd(['cat','/etc/redhat-release']).split()[-2].strip()
	
def main(argv):

	global preOutputs
	

	myPrint('Collecting Outputs')
	
	preOutputs['MOUNTs']=MOUNTs
	preOutputs['IPs']=IPs
	preOutputs['NICs']=NICs
	preOutputs['ROUTEs']=ROUTEs

	if not os.path.exists(workDir):
		os.mkdir(workDir)
		
	collect_Basics()	
	collect_IPs()
	collect_NICs()
	collect_Mounts()
	collect_Routes()

	with open(dumpFile,"w") as fd:
		json.dump(preOutputs,fd,sort_keys = True, indent = 4)
	
	status='OK'	
	print(status)

if __name__ == "__main__" :
	try:
		main(sys.argv[1:])
	except:
		print(status)
		print(sys.exc_info()[0])
		traceback.print_exc()
	
	
