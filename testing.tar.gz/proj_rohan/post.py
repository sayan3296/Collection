#!/usr/bin/env python

from __future__ import print_function
import os;
import sys;
import traceback;
from subprocess import Popen,PIPE,STDOUT;
import json


# Working Directory
workDir='/tmp/OS_patching/'
dumpFile=workDir+'preoutputs.json'
preOutputs={}
postOutputs={}
MOUNTs=[]
IPs=[]
NICs=[]
ROUTEs=[]

MSGS={}

def runCmd(cmd):
	proc=Popen(cmd,stdout=PIPE, stderr=STDOUT)
	output, err=proc.communicate()
	return output.strip()

def collect_IPs():
	out=runCmd(['/sbin/ip','-o','address','show'])
	for line in out.splitlines():		
		if 'inet ' in line:
			if not 'secondary' in line:
				dev=line.split()[1].strip()
			else:
				dev=line.split()[-1].strip()
			ip=line.split()[3].split(r'/')[0].strip()
			sm=line.split()[3].split(r'/')[1].strip()
			IPs.append([dev,ip,sm])	
			
def collect_NICs():
	out=runCmd(['/sbin/ip','-o','link','show'])
	for line in out.splitlines():
		if 'state UP' in line:
			dev=line.split(':')[1].strip()
			NICs.append(dev)
	
def collect_Mounts():
	out=runCmd(['df','-HPT'])
	for line in out.splitlines()[1:]:
		dev,type,size,used,avail,use,point=line.split()
		if type=='tmpfs' or r'/nas/' in point:
			continue
		dev=dev.strip()
		point=point.strip()
		type=type.strip()
		MOUNTs.append([dev,point,type])	
	
def collect_Routes():
	out=runCmd(['/sbin/route','-n'])
	for line in out.splitlines():
		if 'Kernel IP' in line or 'Destination' in line:
			continue
		dest,gw,sm=line.split()[0:3]
		dest=dest.strip()
		gw=gw.strip()
		sm=sm.strip()
		dev=line.split()[-1].strip()
		ROUTEs.append([dest,gw,sm,dev])	

def collect_Basics():
	postOutputs['kernel']=runCmd(['uname','-r'])
	postOutputs['patch']=runCmd(['cat','/etc/ATTPatchlevel']).split(r':')[0]		
	postOutputs['timeZone']=runCmd('date').split()[-2]
	postOutputs['os']=runCmd(['cat','/etc/redhat-release']).split()[-2].strip()
	
def myPrint(desc):
	desc=' ' + desc.strip() + ' '
	print(desc.ljust(42,'.') +' ',end='')
	
def collect_postoutputs():
	myPrint('Collecting PostOutputs')
	collect_Basics()
	collect_IPs()
	collect_NICs()
	collect_Mounts()
	collect_Routes()
	postOutputs['MOUNTs']=MOUNTs
	postOutputs['IPs']=IPs
	postOutputs['NICs']=NICs
	postOutputs['ROUTEs']=ROUTEs	
	print("OK")

def patch_check():

	status='OK'
	msgs=[]
	myPrint('Patch Check')
	
	level='4Q2017'
	KER5='2.6.18-423.el5'
	KER6='2.6.32-696.10.3.el6.x86_64'
	KER7='3.10.0-693.2.2.el7.x86_64'
	myKer=''
	
	rhel=preOutputs['os'].split('.')[0]
	
	if rhel=='5':
		myKer=KER5
	elif rhel=='6':
		myKer=KER6
	elif rhel=='7':
		myKer=KER7
	
	if not myKer==postOutputs['kernel']:
		status='Failed'
		msg='Found Kernel ' + postOutputs['kernel'] + ' ! As per my Knowledge Kernel for 4Q2017 should be ' + myKer 
		msgs.append(msg)

	if not postOutputs['patch']==level:
		status='Failed'
		msg='Found ATTPatchlevel - ' + postOutputs['patch'] + ' ! Current Semester patch - ' + level
		msgs.append(msg)
	
	print(status)
	if msgs:
		MSGS['Patch Check - ISSUES']=msgs	
		
def timezone_check():
	status='OK'
	msgs=[]
	myPrint("TimeZone Check")
	
	if not preOutputs['timeZone']==postOutputs['timeZone']:
		status='Failed'
		msg='Found TimeZone - ' + postOutputs['timeZone'] + ' ! TimeZone in Preoutputs was ' + preOutputs['timeZone']
		msgs.append(msg)
	
	if msgs:
		MSGS['TimeZone Check - ISSUES']=msgs
	print(status)	

def mounts_check():
	status='OK'
	msgs=[]
	myPrint('File Systems Check')
	preMounts=preOutputs['MOUNTs']
	postMounts=postOutputs['MOUNTs']
	
	
	for preMount in preMounts:
		flag=False
		mountDir=preMount[1]
		for postMount in postMounts:
			if mountDir==postMount[1]:
				flag=True
				break
		if not flag:
			msg='Mount Point : ' + preMount[1] + ' is Missing ! '
			msgs.append(msg)
			status='Failed'
	if msgs:
		MSGS['File Systems Check - ISSUES']=msgs
	print(status)

def routes_check():
	status='OK'
	msgs=[]
	myPrint('Routes Check')
	preRoutes=preOutputs['ROUTEs']
	postRoutes=postOutputs['ROUTEs']
	
	for route in preRoutes:
		if not route in postRoutes:
			msg='Found Missing Route - ' + 'Destination - ' + route[0] + ' GW - ' + route[1] + ' SM - ' + route[2] + ' Iface - ' + route[3]
			msgs.append(msg)
			status='Failed'
	if msgs:
		MSGS['Routes Check - ISSUES']=msgs
	print(status)
	
def network_check():
	status='OK'
	msgs=[]
	myPrint("Network Check")
	preIPs=preOutputs['IPs']
	postIPs=postOutputs['IPs']
	
	for IP in preIPs:
		if not IP in postIPs:
			msg='Found Missing IP  - ' + IP[1] + r'/' + IP[2] + ' Device - ' + IP[0]
			msgs.append(msg)
			status='Failed'
			
	preIFs=preOutputs['NICs']
	postIFs=postOutputs['NICs']
	
	for IFace in preIFs:
		if not IFace in postIFs:
			msg='Found ' + IFace + ' Interface is Down/Missing !'
			msgs.append(msg)
			status='Failed'
			
	if msgs:
		MSGS['Network Check - ISSUES']=msgs
	print(status)
	
def print_msgs():

	 if MSGS:
		#print('')
		print(r'!!! Some problems have been found !!!')
		for key in MSGS.keys():
			print('')
			print(r'==> ' + key )
			for msg in MSGS[key][:]:
				print('* ' + msg)
				
	
def main(argv):
	
	global preOutputs,postOutputs
	
	myPrint('Preoutputs Present ? ')
	if not os.path.isfile(dumpFile):
			print('Failed')
			return 
	else:
		with open(dumpFile,"r") as fd:
			preOutputs=json.load(fd)
			print('OK')	

	collect_postoutputs()
	patch_check()
	timezone_check()
	mounts_check()
	network_check()
	routes_check()
	print_msgs()
	print_msgs

if __name__ == "__main__" :
	try:
		main(sys.argv[1:])
	except:
		print(sys.exc_info()[0])
		traceback.print_exc()

