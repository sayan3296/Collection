######  Working Directory
MAINDIR=/tmp/patching/
PREDIR=/tmp/patching/preoutputs;
POSTDIR=/tmp/patching/postoutputs;
MSGS[0]=""
MSGCNT=-1
PRECHECK()
{
printf " Preoutputs Present ? ................... "
sleep 0.5
## Checking Preoutputs Directory
if ! [ -d $PREDIR ] ; then
let "++MSGCNT"
MSGS[$MSGCNT]="Preouputs Directory Missing ! Exiting Postwork"
printf "Failed\n"
MSGSPRINT
exit 1
fi

printf "OK\n"
}

MOUNTCHECK()
{

printf " Mount Points Check ..................... "
sleep 0.5

STATUS=0
MNTMISSSNG1=$( comm -23 "${PREDIR}/df" "${POSTDIR}/df" | egrep -v "^$" );
if [[ `printf "${MNTMISSSNG1}" | wc -c` -ne 0 ]]; then
let "++MSGCNT";
MSGS[$MSGCNT]=" *** Following Mount points Are Missing :\n $MNTMISSSNG1"
STATUS=1
fi

MNTMISSSNG2=$( comm -13 "${PREDIR}/df" "${POSTDIR}/df" | egrep -v "^$" );
if [[ `printf "${MNTMISSSNG2}" | wc -c` -ne 0 ]]; then
let "++MSGCNT";
MSGS[$MSGCNT]=" *** Extra Mount points :\n $MNTMISSSNG2"
STATUS=1
fi

if [[ $STATUS -eq 0 ]] ; then
printf "OK\n"
else
printf "Failed\n"
fi
}

MSGSPRINT()

{

if [[ $MSGCNT -eq '-1' ]] ; then
return 1
fi
printf "\n++++++++++++++++++++++++++++++++++++++++\n"
for i in `seq 0 $MSGCNT`;do
printf "${MSGS[$i]}\n"
done
}

POSTOUTPUTS()
{

printf " Taking PostOutputs ..................... "
sleep 0.5

if ! [ -d $POSTDIR ] ; then
/bin/mkdir -p $POSTDIR ; fi;
cd $POSTDIR;

/bin/df -hPTx tmpfs | awk 'NR > 1{print $7}' | egrep -v "^\/nas" |  sort -k 7 > df
/sbin/ip route show | /bin/sort > route
echo "`/bin/date | /bin/awk '{print $5}'`" > zone
 /sbin/ip -o addr show | /bin/awk -F 'scope' '/\<inet\>/{ split($1,a,":");gsub(/^[ \t]+/, "",a[2]);print a[2] }'| /bin/sort | /usr/bin/tr -s ' ' > ip_addr
 /sbin/ip -o link show | /bin/awk -F 'state' '/UP/{split($1,a,":");split($2,b," ");gsub(/^[ \t]+/, "",a[2]);print a[2],b[1]}' | /bin/sort > dev_state

 printf "OK\n"

 }

 PATCHCHECK()
 {
 printf " Patch Check ............................ "
 STATUS=0
 LEVEL="2Q2018"
 KER5="2.6.18-426.el5"
 KER6="2.6.32-696.20.1.el6.x86_64"
 KER7="3.10.0-693.17.1.el7.x86_64"
 CURRKERN=`uname -r`
 CURRLEVEL=`awk -F ':' '{print $1}' /etc/ATTPatchlevel`
 rhel=`awk -F '.' '{print $1}' /etc/redhat-release | tail -c 2`

 case $rhel in
 "5") if [[ $CURRKERN != $KER5 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Current kernel $CURRKERN doesnt Match kernel $KER5 for $LEVEL"
 STATUS=1
 fi
 ;;
 "6") if [[ $CURRKERN != $KER6 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Current kernel $CURRKERN doesnt Match kernel $KER6 for $LEVEL"
 STATUS=1
 fi
 ;;
 "7") if [[ $CURRKERN != $KER7 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Current kernel $CURRKERN doesnt Match kernel $KER7 for $LEVEL"
 STATUS=1
 fi
 ;;
 esac

 if [[ $CURRLEVEL != $LEVEL ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Current ATTPatchlevel $CURRLEVEL doesnt Match Current Semester patch level $LEVEL"
 STATUS=1
 fi

 if [[ $STATUS -eq 0 ]] ; then
 printf "OK\n"
 else
 printf "Failed\n"
 fi
 }

 TIMEZONECHECK ()
 {

 printf " Timezone Check ......................... "

 CURRZONE=$(/bin/date | /bin/awk '{print $5}')
 OLDZONE=$(cat ${PREDIR}/zone)

 if [[ $OLDZONE != $CURRZONE ]] ; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Timezone Changed after patch. Old - $OLDZONE  New - $CURRZONE"
 printf "Failed\n"
 return 1
 fi

 printf "OK\n"

 }

 ROUTECHECK ()
 {
 printf " Routes Check ........................... "

 STATUS=0

 ROUTEMISSSNG1=$( comm -23 "${PREDIR}/route" "${POSTDIR}/route" | egrep -v "^$" );
 if [[ `printf "${ROUTEMISSSNG1}" | wc -c` -ne 0 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Following Routes Are Missing :\n $ROUTEMISSSNG1"
 STATUS=1
 fi

 ROUTEMISSSNG2=$( comm -13 "${PREDIR}/route" "${POSTDIR}/route" | egrep -v "^$" );
 if [[ `printf "${ROUTEMISSSNG2}" | wc -c` -ne 0 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Extra Routes Found :\n $ROUTEMISSSNG2"
 STATUS=1
 fi

 if [[ $STATUS -eq 0 ]] ; then
 printf "OK\n"
 else
 printf "Failed\n"
 fi

 }

 NETWORKCHECK ()
 {

 printf " Network Check .......................... "

 STATUS=0
 IPMISSING=$( comm -23 "${PREDIR}/ip_addr" "${POSTDIR}/ip_addr" | egrep -v "^$" );
 if [[ `printf "${IPMISSING}" | wc -c` -ne 0 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Following IP Addresses Are Missing :\n $IPMISSING"
 STATUS=1
 fi

 STATEDOWN=$( comm -23 "${PREDIR}/dev_state" "${POSTDIR}/dev_state" | egrep -v "^$" );
 if [[ `printf "${STATEDOWN}" | wc -c` -ne 0 ]]; then
 let "++MSGCNT";
 MSGS[$MSGCNT]=" *** Following Network Devices are down/missing :\n $STATEDOWN"
 STATUS=1
 fi

 if [[ $STATUS -eq 0 ]] ; then
 printf "OK\n"
 else
 printf "Failed\n"
 fi

 }


 PRECHECK

 POSTOUTPUTS

 PATCHCHECK

 MOUNTCHECK

 ROUTECHECK

 NETWORKCHECK

 TIMEZONECHECK


 MSGSPRINT

